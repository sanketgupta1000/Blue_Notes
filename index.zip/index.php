<?php
    header('Location: user_account/user_account.php?signup');
?>